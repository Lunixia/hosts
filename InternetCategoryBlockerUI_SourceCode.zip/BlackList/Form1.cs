﻿using System;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;
using System.Threading;


namespace BlackList
{
    public partial class Form1 : Form
    {
        static string whitelistfile = Environment.CurrentDirectory + @"\whitelist";
        static string blacklistfile = Environment.CurrentDirectory + @"\blacklist";
        static string hostsfile = Environment.CurrentDirectory + @"\hosts";

        public Form1()
        {
            InitializeComponent();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is a User Interface designed to help the average user protect " +
                            "themselves against internet sites by category or by allowing them to " +
                            "manually configure white/black lists without using the command line.", 
                            "About",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveLists(whitelistfile, tb_WhiteList);
            SaveLists(blacklistfile, tb_BlackList);
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tb_WhiteList.Text = GetList(whitelistfile);
            tb_BlackList.Text = GetList(blacklistfile);
        }

        private void Form1_Closing(object sender, EventArgs e)
        {
            SaveLists(whitelistfile, tb_WhiteList);
            SaveLists(blacklistfile, tb_BlackList);
            Application.Exit();
        }

        private void SaveLists(string loc, TextBox obj)
        {
            File.Delete(loc);
            StreamWriter SW = new StreamWriter(loc);
            SW.Write(obj.Text);
            SW.Close();
        }

        private String GetList(string loc)
        {
            StreamReader SR = new StreamReader(loc);
            string s = SR.ReadToEnd();
            SR.Close();
            return s;
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            textBox3.Text = "";

            SaveLists(whitelistfile, tb_WhiteList);
            SaveLists(blacklistfile, tb_BlackList);

            if (!File.Exists(@"C:\Windows\System32\drivers\etc\hosts.skel"))
            {
                File.Copy(@"C:\Windows\System32\drivers\etc\hosts", @"C:\Windows\System32\drivers\etc\hosts.skel", true);
            }

            string args = GetArgs();

            try
            {
                ProcKickOff(@"C:\python27\python.exe", "updateHostsFile.py " + args);
                tb_log.Text = "Configuration Built.";
                Application.DoEvents();
                Thread.Sleep(1000);
            }
            catch
            {
            }

            Thread.Sleep(1000);
            File.Copy(hostsfile, @"C:\Windows\System32\drivers\etc\hosts", true);
            tb_log.Text = "Configuration file copied.";

            Thread.Sleep(1000);
            ProcKickOff("cmd.exe", "/C ipconfig.exe /flush");
            tb_log.Text = "Network Resolution Flushed.";
            Application.DoEvents();
            Thread.Sleep(1000);

            tb_log.Text = "Confuration Complete.";
            Application.DoEvents();
            Thread.Sleep(1000);

            textBox3.Text = GetList(@"C:\Windows\System32\drivers\etc\hosts");
            Application.DoEvents();
        }

        private void ProcKickOff(string exec, string args)
        {
            ProcessStartInfo procStartInfo = new ProcessStartInfo(exec, args);
            procStartInfo.RedirectStandardOutput = false;
            procStartInfo.UseShellExecute = false;
            procStartInfo.CreateNoWindow = false;
            Process proc = new Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            while(!proc.HasExited)
            {
                Application.DoEvents();
                Thread.Sleep(500);
            }
        }

        private string GetArgs()
        {
            String arg = "-a";
            if(chk_fake.Checked || chk_gamble.Checked || chk_porn.Checked)
            {
                arg += " -e";
            }
            if (chk_fake.Checked)
            {
                arg += " fakenews";
            }
            if (chk_gamble.Checked)
            {
                arg += " gambling";
            }
            if (chk_porn.Checked)
            {
                arg += " porn";
            }
            if (chk_social.Checked)
            {
                arg += " social";
            }
            return arg;
        }

        private bool CheckForPython()
        {
            if (File.Exists(@"C:\python27\python.exe"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!CheckForPython())
            {
                try
                {
                    ProcKickOff("msiexec.exe", "/i python-2.7.14.msi /passive");
                    Application.DoEvents();
                }
                catch
                {
                }
            }
            tb_log.Text = "Python Installed/Verified.";
        }
    }
}
